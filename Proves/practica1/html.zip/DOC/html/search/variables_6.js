var searchData=
[
  ['pare',['pare',['../struct_poblacio_1_1info__individu.html#ac636608927ac98728476ef7e60e50bb6',1,'Poblacio::info_individu']]],
  ['poblacio',['poblacio',['../class_poblacio.html#a4b89b2319be339b49a0d491bb14596e1',1,'Poblacio']]]
];
