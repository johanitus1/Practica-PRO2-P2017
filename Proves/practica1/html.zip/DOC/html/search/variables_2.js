var searchData=
[
  ['individu',['individu',['../struct_poblacio_1_1info__individu.html#a566d1ffa35dcfe9db6d9787cbf37376c',1,'Poblacio::info_individu']]]
];
