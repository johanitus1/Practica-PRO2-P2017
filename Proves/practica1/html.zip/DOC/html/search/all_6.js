var searchData=
[
  ['main',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['map_5fiterator',['map_iterator',['../class_poblacio.html#ab72262390a1bd4de9c057dcbb8e945ac',1,'Poblacio']]],
  ['mare',['mare',['../struct_poblacio_1_1info__individu.html#aa053f74a366a1e298aa2390ae8027c20',1,'Poblacio::info_individu']]],
  ['mida',['mida',['../class_cromosoma.html#a039da12b7d6838526f887cd888ec7ce8',1,'Cromosoma']]],
  ['modificar_5fgen',['modificar_gen',['../class_cromosoma.html#a48af4e90776f362369cd5b921f51434b',1,'Cromosoma']]]
];
