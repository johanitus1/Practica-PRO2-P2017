var searchData=
[
  ['cromosoma1',['cromosoma1',['../class_parell___cromosomes.html#a58992fef5e9faa4549c1b6e898becc7c',1,'Parell_Cromosomes']]],
  ['cromosoma2',['cromosoma2',['../class_parell___cromosomes.html#a1de874cd3304dba11b0663db14999a9a',1,'Parell_Cromosomes']]],
  ['cromosomes_5fnormals',['cromosomes_normals',['../class_individu.html#a18331aa8ef2d85cdaa801485a11eb6dd',1,'Individu']]],
  ['cromosomes_5fsexuals',['cromosomes_sexuals',['../class_individu.html#a63012f06991fc38e812f9504b649363b',1,'Individu']]]
];
