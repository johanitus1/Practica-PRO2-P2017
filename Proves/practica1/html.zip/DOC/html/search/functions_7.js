var searchData=
[
  ['reproduir',['reproduir',['../class_poblacio.html#a1f7ae5a104ba6f2f8afbd26bdf8230c7',1,'Poblacio']]]
];
