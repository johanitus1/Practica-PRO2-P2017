var searchData=
[
  ['individu',['Individu',['../class_individu.html#ac35091404cfbf11946694806aefa9e7e',1,'Individu::Individu()'],['../class_individu.html#a13959903c4de9d437d094c2faf9f5288',1,'Individu::Individu(char sexe, const Parell_Cromosomes &amp;cromosomes_sexuals, const vector&lt; Parell_Cromosomes &gt; &amp;cromosomes_normals)']]],
  ['input_5fand_5fcompleta_5farbre',['input_and_completa_arbre',['../class_poblacio.html#aa34d69370c9b621483fadcaf8ff76e19',1,'Poblacio']]]
];
