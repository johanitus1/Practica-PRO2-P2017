var searchData=
[
  ['llegir',['llegir',['../class_cromosoma.html#a952f1237b758c21ac2629c7cae7c34ae',1,'Cromosoma::llegir()'],['../class_especie.html#a7384add391d2684c4fb6bdf8a535fba3',1,'Especie::llegir()'],['../class_individu.html#aeae0eb40b4d7da65369ccd7c83affab4',1,'Individu::llegir()'],['../class_parell___cromosomes.html#a27d6196fc4b57d6e96d5fed5996b18f8',1,'Parell_Cromosomes::llegir()']]],
  ['llegirindividu',['llegirIndividu',['../class_poblacio.html#a872d4d6fc03a17af71d1ca1bbfc69754',1,'Poblacio']]]
];
