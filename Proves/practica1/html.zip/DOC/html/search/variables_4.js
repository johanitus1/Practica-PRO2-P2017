var searchData=
[
  ['mare',['mare',['../struct_poblacio_1_1info__individu.html#aa053f74a366a1e298aa2390ae8027c20',1,'Poblacio::info_individu']]]
];
