var searchData=
[
  ['individu',['Individu',['../class_individu.html',1,'']]],
  ['info_5findividu',['info_individu',['../struct_poblacio_1_1info__individu.html',1,'Poblacio']]]
];
