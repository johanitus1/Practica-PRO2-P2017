var searchData=
[
  ['gens',['gens',['../class_cromosoma.html#a77c9b34a325c454f37a6b3af65fec6de',1,'Cromosoma']]]
];
