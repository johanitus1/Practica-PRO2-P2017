var searchData=
[
  ['map_5fiterator',['map_iterator',['../class_poblacio.html#ab72262390a1bd4de9c057dcbb8e945ac',1,'Poblacio']]]
];
