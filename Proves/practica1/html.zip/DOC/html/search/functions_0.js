var searchData=
[
  ['afegirindividu',['afegirIndividu',['../class_poblacio.html#a3dabc128a2939f90fadeff9d6db22b11',1,'Poblacio']]],
  ['arbrein',['ArbreIn',['../_arbre_i_o_8hh.html#a841c7d5d5e03e8947d8aafe35cf644ff',1,'ArbreIO.hh']]],
  ['arbreout',['ArbreOut',['../_arbre_i_o_8hh.html#ab59ea7cb15acc2f627d9cdd1fe7c89a1',1,'ArbreIO.hh']]]
];
