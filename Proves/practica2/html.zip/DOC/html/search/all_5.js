var searchData=
[
  ['l',['l',['../class_especie.html#ae32ed22b56d80f11c181911c67fa0e95',1,'Especie']]],
  ['l0',['l0',['../class_especie.html#adc05a1292f9c9a887164b41ba236b187',1,'Especie']]],
  ['llegir',['llegir',['../class_cromosoma.html#a952f1237b758c21ac2629c7cae7c34ae',1,'Cromosoma::llegir()'],['../class_especie.html#a7384add391d2684c4fb6bdf8a535fba3',1,'Especie::llegir()'],['../class_individu.html#aeae0eb40b4d7da65369ccd7c83affab4',1,'Individu::llegir()'],['../class_parell___cromosomes.html#a27d6196fc4b57d6e96d5fed5996b18f8',1,'Parell_Cromosomes::llegir()']]],
  ['llegirindividu',['llegirIndividu',['../class_poblacio.html#a872d4d6fc03a17af71d1ca1bbfc69754',1,'Poblacio']]],
  ['lx',['lx',['../class_especie.html#ade4c4e0e145af39d14078b08b3b03df8',1,'Especie']]],
  ['ly',['ly',['../class_especie.html#a5d8a4e5dced433508eb01bd748c6b562',1,'Especie']]]
];
