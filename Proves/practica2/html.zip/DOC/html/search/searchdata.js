var indexSectionsWithContent =
{
  0: "acegilmnprs",
  1: "ceip",
  2: "aceip",
  3: "aceilmpr",
  4: "cgilmnps",
  5: "cm"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Variables",
  5: "Definicions de Tipus"
};

