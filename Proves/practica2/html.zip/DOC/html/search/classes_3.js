var searchData=
[
  ['parell_5fcromosomes',['Parell_Cromosomes',['../class_parell___cromosomes.html',1,'']]],
  ['poblacio',['Poblacio',['../class_poblacio.html',1,'']]]
];
