var searchData=
[
  ['pare',['pare',['../struct_poblacio_1_1info__individu.html#ac636608927ac98728476ef7e60e50bb6',1,'Poblacio::info_individu']]],
  ['parell_5fcromosomes',['Parell_Cromosomes',['../class_parell___cromosomes.html',1,'Parell_Cromosomes'],['../class_parell___cromosomes.html#a584c2ed744a71896a2d59f9a30e80387',1,'Parell_Cromosomes::Parell_Cromosomes()'],['../class_parell___cromosomes.html#a81bc0116a6d3843a8e01ff9132604e5a',1,'Parell_Cromosomes::Parell_Cromosomes(int l1, int l2)'],['../class_parell___cromosomes.html#a040e6ea3253b4b52fadb395771657781',1,'Parell_Cromosomes::Parell_Cromosomes(const Cromosoma &amp;c1, const Cromosoma &amp;c2)']]],
  ['parell_5fcromosomes_2ecc',['Parell_Cromosomes.cc',['../_parell___cromosomes_8cc.html',1,'']]],
  ['parell_5fcromosomes_2ehh',['Parell_Cromosomes.hh',['../_parell___cromosomes_8hh.html',1,'']]],
  ['poblacio',['Poblacio',['../class_poblacio.html',1,'Poblacio'],['../class_poblacio.html#ac0183157c2cdadc3ef95d11b6614700a',1,'Poblacio::Poblacio()'],['../class_poblacio.html#a4b89b2319be339b49a0d491bb14596e1',1,'Poblacio::poblacio()']]],
  ['poblacio_2ecc',['Poblacio.cc',['../_poblacio_8cc.html',1,'']]],
  ['poblacio_2ehh',['Poblacio.hh',['../_poblacio_8hh.html',1,'']]],
  ['posible_5freproduccio',['posible_reproduccio',['../class_poblacio.html#a0df229fbe005423130d5f8f660a83f44',1,'Poblacio']]],
  ['program_2ecc',['program.cc',['../program_8cc.html',1,'']]]
];
