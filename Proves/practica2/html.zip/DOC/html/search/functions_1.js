var searchData=
[
  ['completa_5farbre',['completa_arbre',['../class_poblacio.html#a3788df51baa34c73bed5bb17c64d65e0',1,'Poblacio']]],
  ['completaarbre',['completaArbre',['../class_poblacio.html#a3cd1767441110e3b38890b8e44cf58df',1,'Poblacio']]],
  ['consultar_5fc1',['consultar_c1',['../class_parell___cromosomes.html#a2f8d2e72b70b588051571664fdc39e00',1,'Parell_Cromosomes']]],
  ['consultar_5fc2',['consultar_c2',['../class_parell___cromosomes.html#a214daceed049a7cb0d8a0baf155d266d',1,'Parell_Cromosomes']]],
  ['consultar_5fgen',['consultar_gen',['../class_cromosoma.html#a2eaaadd57ed2ee1c89d0d0eea6252bba',1,'Cromosoma']]],
  ['consultar_5fl0',['consultar_l0',['../class_especie.html#af4574f29cff6936b22debc60ac9ecfd7',1,'Especie']]],
  ['consultar_5fli',['consultar_li',['../class_especie.html#acfeb7d640bb6c73d74fca4ba1344da05',1,'Especie']]],
  ['consultar_5flx',['consultar_lx',['../class_especie.html#a35b595c9f7dcf3e23b9c85278f72322e',1,'Especie']]],
  ['consultar_5fly',['consultar_ly',['../class_especie.html#afba7e27b8516600f74ff683b90e9fa40',1,'Especie']]],
  ['consultar_5fn',['consultar_N',['../class_especie.html#a23b157634571663dc48671648ef0cb96',1,'Especie']]],
  ['consultarcromosomanormal',['consultarCromosomaNormal',['../class_individu.html#a248e74b4cf33cbfb55714260b035b475',1,'Individu']]],
  ['consultarcromosomasexual',['consultarCromosomaSexual',['../class_individu.html#a433a04f381273de0a47492470124500b',1,'Individu']]],
  ['consultarsexe',['consultarSexe',['../class_individu.html#a12a1e16275bbad2066f400b93b453ade',1,'Individu']]],
  ['creuacromosomesnormals',['creuaCromosomesNormals',['../class_poblacio.html#ac67619725be6d11e5ed872b1d186749f',1,'Poblacio']]],
  ['creuacromosomessexuals',['creuaCromosomesSexuals',['../class_poblacio.html#a113091b96caec405a443a48847dfc2c5',1,'Poblacio']]],
  ['cromosoma',['Cromosoma',['../class_cromosoma.html#a8367f3dd60c6af083aed533c69f17b29',1,'Cromosoma::Cromosoma()'],['../class_cromosoma.html#ae601c36bf2624be114715ae67f42daba',1,'Cromosoma::Cromosoma(int l)']]]
];
