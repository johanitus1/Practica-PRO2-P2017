var searchData=
[
  ['cromosoma',['Cromosoma',['../class_cromosoma.html',1,'']]]
];
