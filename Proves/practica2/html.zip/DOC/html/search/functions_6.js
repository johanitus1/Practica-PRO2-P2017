var searchData=
[
  ['parell_5fcromosomes',['Parell_Cromosomes',['../class_parell___cromosomes.html#a584c2ed744a71896a2d59f9a30e80387',1,'Parell_Cromosomes::Parell_Cromosomes()'],['../class_parell___cromosomes.html#a81bc0116a6d3843a8e01ff9132604e5a',1,'Parell_Cromosomes::Parell_Cromosomes(int l1, int l2)'],['../class_parell___cromosomes.html#a040e6ea3253b4b52fadb395771657781',1,'Parell_Cromosomes::Parell_Cromosomes(const Cromosoma &amp;c1, const Cromosoma &amp;c2)']]],
  ['poblacio',['Poblacio',['../class_poblacio.html#ac0183157c2cdadc3ef95d11b6614700a',1,'Poblacio']]],
  ['posible_5freproduccio',['posible_reproduccio',['../class_poblacio.html#a0df229fbe005423130d5f8f660a83f44',1,'Poblacio']]]
];
